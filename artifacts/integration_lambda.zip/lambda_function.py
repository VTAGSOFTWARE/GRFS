def lambda_handler(event, context):
    print("EVENT RECEIVED:", event)
    return {
        "statusCode": 200,
        "body": "infra test"
    }
